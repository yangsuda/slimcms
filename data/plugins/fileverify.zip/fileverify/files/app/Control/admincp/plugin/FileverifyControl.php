<?php
/**
 * 后台首页控制类
 * @author zhucy
 */

declare(strict_types=1);

namespace App\Control\admincp\plugin;

use App\Control\admincp\AdmincpControl;
use App\Model\plugin\fileverify\FileverifyModel;
use App\Model\plugin\PluginModel;
use SlimCMS\Core\Request;
use SlimCMS\Core\Response;
use SlimCMS\Error\TextException;

class FileverifyControl extends AdmincpControl
{
    private static $identifier = 'fileverify';

    public function __construct(Request $request, Response $response)
    {
        parent::__construct($request, $response);
        $res = PluginModel::getConfig(self::$identifier);
        if ($res->getCode() != 200) {
            throw new TextException($res->getCode());
        }
    }

    /**
     * 文件校验
     * @return array
     */
    public function fileVerify()
    {
        $this->checkAllow();
        $res = FileverifyModel::fileVerify()->withReferer(self::url('?p=plugin/fileverify/dataList'));
        return $this->directTo($res);
    }

    /**
     * 更新文件校验KEY
     * @return array
     */
    public function updateVerifyKey()
    {
        $this->checkAllow();
        $file = self::inputString('file');
        $res = FileverifyModel::updateVerifyKey($file)->withReferer(self::url('?p=plugin/fileverify/dataList'));
        return $this->directTo($res);
    }

    /**
     * 列表跳转
     * @return \Psr\Http\Message\ResponseInterface
     * @throws TextException
     */
    public function dataList()
    {
        $fid = self::t('forms')->withWhere(['table'=>'fileverify'])->fetch('id');
        return self::$response->getResponse()
            ->withHeader('location', self::url('?p=forms/dataList&fid='.$fid));
    }
}
