<?php

/**
 * @author zhucy
 */

declare(strict_types=1);

namespace App\Model\plugin\fileverify;

use SlimCMS\Abstracts\ModelAbstract;
use SlimCMS\Helper\Ipdata;
use SlimCMS\Interfaces\OutputInterface;

class FileverifyModel extends ModelAbstract
{
    /**
     * 指定此三个文件夹文件做安全校验
     */
    public static function fileVerify(): OutputInterface
    {
        $dirs = ['app', 'template', 'vendor'];
        foreach ($dirs as $dir) {
            self::getFiles(CSROOT . $dir);
        }
        //检测是否有删除
        $list = self::t('fileverify')->fetchList();
        foreach ($list as $v) {
            if (!is_file(CSROOT . $v['filename'])) {
                self::t('fileverify')->withWhere($v['id'])->update(['status' => 4]);
            }
        }
        return self::output()->withCode(200);
    }

    /**
     * 遍历相关文件夹并将所有文件key入库
     * @param $directory
     */
    private static function getFiles($directory)
    {
        $exempt = ['.', '..', '.ds_store', '.svn'];
        $directory = preg_replace("/\/$/", "", $directory) . '/';
        $handle = opendir($directory);
        while (false !== ($resource = readdir($handle))) {
            if (!in_array(strtolower($resource), $exempt)) {
                //排除目录
                if (is_dir($directory . $resource . '/')) {
                    self::getFiles($directory . $resource . '/');
                } else {
                    $file = $directory . $resource;
                    $srcverifykey = md5_file($file);
                    $filename = str_replace(CSROOT, '', $file);
                    $row = self::t('fileverify')->withWhere(['filename' => $filename])->fetch();
                    if (empty($row)) {
                        $data = ['filename' => $filename, 'srcverifykey' => $srcverifykey, 'status' => 3, 'createtime' => TIMESTAMP, 'ip' => Ipdata::getip()];
                        self::t('fileverify')->insert($data);
                    } else {
                        $status = $row['srcverifykey'] == $srcverifykey ? 1 : 2;
                        $data = ['curverifykey' => $srcverifykey, 'status' => $status];
                        self::t('fileverify')->withWhere($row['id'])->update($data);
                    }
                }
            }
        }
        closedir($handle);
    }

    /**
     * 更新文件校验KEY
     * @param $file
     * @return array
     */
    public static function updateVerifyKey(string $file): OutputInterface
    {
        if (empty($file)) {
            return self::output()->withCode(21002);
        }
        $row = self::t('fileverify')->withWhere(['filename' => $file])->fetch();
        if (empty($row)) {
            return self::output()->withCode(21001);
        }
        if (!is_file(CSROOT . $row['filename'])) {
            self::t('fileverify')->withWhere($row['id'])->delete();
        } else {
            $data = ['srcverifykey' => $row['curverifykey'], 'status' => 1];
            self::t('fileverify')->withWhere($row['id'])->update($data);
        }
        return self::output()->withCode(200);
    }

    /**
     * 注入插件提示信息的输出类
     * @return OutputInterface
     */
    public static function output(): OutputInterface
    {
        return self::$output->withPrompt(self::prompt());
    }

    /**
     * 插件提示信息(防止与原提示代码重复，以9000000开始)
     * @return array
     */
    private static function prompt(): array
    {
        return [];
    }
}
