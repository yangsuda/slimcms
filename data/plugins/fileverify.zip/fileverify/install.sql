
DROP TABLE IF EXISTS `#@#fileverify`;
CREATE TABLE `#@#fileverify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ischeck` tinyint(1) NOT NULL DEFAULT '2' COMMENT '是否审核(1=已审核，2=未审核)',
  `createtime` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(20) NOT NULL DEFAULT '',
  `filename` varchar(250) NOT NULL DEFAULT '' COMMENT '文件名称',
  `srcverifykey` varchar(250) NOT NULL DEFAULT '' COMMENT '原始文件校验码',
  `curverifykey` varchar(250) NOT NULL DEFAULT '' COMMENT '当前文件校验码',
  `status` tinyint(1) NOT NULL DEFAULT '3' COMMENT '状态(1=正常,2=改动,3=新增,4=删除)',
  PRIMARY KEY (`id`),
  KEY `issame` (`status`),
  KEY `filename` (`filename`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件安全校验';

INSERT INTO `#@#forms` (`id`,`name`,`table`,`export`,`cpcheck`,`isarchive`,`createtime`,`ischeck`,`cpadd`,`types`,`cpdel`) VALUES
(null, '文件安全校验', 'fileverify', '2', '2', '2', '1632274349', '2', '1', 'fas fa-cog', '1');

INSERT INTO `#@#forms_fields` VALUES
(null, '文件名称', 'filename', '-1', 'text', '50', '1', '1', '2', '2', '1', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1601194155', '1', '', '', '', '0.0000', '2', '3', '1', ''),
(null, '原始文件校验码', 'srcverifykey', '-1', 'text', '49', '1', '1', '2', '2', '2', '2', '2', '2', '1', '', '0', '', '', '', '', '', '', '', '', '1601194456', '1', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '当前文件校验码', 'curverifykey', '-1', 'text', '48', '1', '1', '2', '2', '2', '2', '2', '2', '1', '', '0', '', '', '', '', '', '', '', '', '1601194504', '1', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '状态', 'status', '-1', 'select', '47', '1', '1', '2', '2', '1', '1', '2', '1', '1', '3', '0', '', '', '', '', 'a:4:{i:1;s:6:\"正常\";i:2;s:6:\"改动\";i:3;s:6:\"新增\";i:4;s:6:\"删除\";}', '', '', '', '1601194681', '1', '', '', 'tinyint', '1.0000', '1', '1', '1', '');
