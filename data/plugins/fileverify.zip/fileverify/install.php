<?php
return [
    'tables' => [
        -1 => 'fileverify',
    ],
];
