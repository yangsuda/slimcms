<?php

/**
 * @author zhucy
 */

declare(strict_types=1);

namespace App\Model\plugin\files;

use App\Core\Forms;
use SlimCMS\Abstracts\ModelAbstract;
use SlimCMS\Helper\File;
use SlimCMS\Helper\Str;
use SlimCMS\Helper\Zip;
use SlimCMS\Interfaces\OutputInterface;

class FilesModel extends ModelAbstract
{
    /**
     * 注入插件提示信息的输出类
     * @return OutputInterface
     */
    public static function output(): OutputInterface
    {
        return self::$output->withPrompt(self::prompt());
    }

    /**
     * 插件提示信息(防止与原提示代码重复，以9100000开始)
     * @return array
     */
    private static function prompt(): array
    {
        return [
            9100001 => '此文件夹不存在',
            9100002 => '此文件名文件已存在',
            9100003 => '此文件夹已存在',
            9100004 => '此文件名文件已存在，更名失败！',
            9100005 => '此文件不可写，更名失败！',
            9100006 => '此文件不存在',
        ];
    }

    /**
     * 文件检测，防止操作除app、template、public以外的文件
     * @param string $file
     * @return OutputInterface
     */
    private static function fileCheck(string $file): OutputInterface
    {
        if (empty($file)) {
            return self::output()->withCode(21003);
        }
        $file = trim($file, '/');
        $dir = strpos($file, '/') ? strstr($file, '/', true) : $file;
        if (!in_array($dir, ['app', 'template', 'public'])) {
            return self::output()->withCode(9100001);
        }
        return self::output()->withCode(200);
    }

    /**
     * 文件列表
     * @param string $dirpath 文件夹URL
     * @return OutputInterface
     */
    public static function fileList(string $dirpath = ''): OutputInterface
    {
        $inpath = CSROOT . (!empty($dirpath) ? $dirpath : '');
        if (!is_dir($inpath)) {
            return self::output()->withCode(9100001);
        }
        $dh = @dir($inpath);
        $files = $dirs = $back = $d = $f = [];
        while (($file = $dh->read()) !== false) {
            if (empty($dirpath) && !in_array($file, ['app', 'template', 'public'])) {
                continue;
            }
            if ($file != "." && $file != "..") {
                if (!is_dir("$inpath/$file")) {
                    $filesize = filesize("$inpath/$file");
                    $filesize = round($filesize / 1024, 2);
                }
                $filemtime = filemtime("$inpath/$file");
                $filetime = date("Y-m-d H:i:s", $filemtime);
                $key = $file;
            }
            if ($file == ".") {
                continue;
            } elseif ($file == "..") {
                if ($dirpath == "") {
                    continue;
                }
                $line = array();
                $line['dirpath'] = urlencode(preg_replace("#[\/][^\/]*$#i", "", $dirpath));
                $back[] = $line;
            } elseif (is_dir("$inpath/$file")) {
                if (preg_match("/^[\.](.*)$/i", $file))
                    continue;
                $dirs[$key] = array('file' => $file, 'filetime' => $filetime);
                $d[] = $key;
            } elseif (preg_match("#\.(gif|png)#i", $file)) {
                $files[$key] = array('file' => $file, 'icon' => 'gif', 'filesize' => $filesize, 'filetime' => $filetime, 'isedit' => false);
                $f[] = $key;
            } elseif (preg_match("#\.(jpg)#i", $file)) {
                $files[$key] = array('file' => $file, 'icon' => 'jpg', 'filesize' => $filesize, 'filetime' => $filetime, 'isedit' => false);
                $f[] = $key;
            } else if (preg_match("#\.(swf|fla|fly)#i", $file)) {
                $files[$key] = array('file' => $file, 'icon' => 'flash', 'filesize' => $filesize, 'filetime' => $filetime, 'isedit' => false);
                $f[] = $key;
            } elseif (preg_match("#\.(zip|rar|tar.gz)#i", $file)) {
                $files[$key] = array('file' => $file, 'icon' => 'zip', 'filesize' => $filesize, 'filetime' => $filetime, 'isedit' => false);
                $f[] = $key;
            } elseif (preg_match("#\.(exe)#i", $file)) {
                $files[$key] = array('file' => $file, 'icon' => 'exe', 'filesize' => $filesize, 'filetime' => $filetime, 'isedit' => false);
                $f[] = $key;
            } elseif (preg_match("#\.(mp3|wma)#i", $file)) {
                $files[$key] = array('file' => $file, 'icon' => 'mp3', 'filesize' => $filesize, 'filetime' => $filetime, 'isedit' => false);
                $f[] = $key;
            } elseif (preg_match("#\.(wmv|api)#i", $file)) {
                $files[$key] = array('file' => $file, 'icon' => 'wmv', 'filesize' => $filesize, 'filetime' => $filetime, 'isedit' => false);
                $f[] = $key;
            } elseif (preg_match("#\.(rm|rmvb)#i", $file)) {
                $files[$key] = array('file' => $file, 'icon' => 'rm', 'filesize' => $filesize, 'filetime' => $filetime, 'isedit' => false);
                $f[] = $key;
            } else if (preg_match("#\.(txt|inc|pl|cgi|asp|xml|xsl|aspx|cfm)#", $file)) {
                $files[$key] = array('file' => $file, 'icon' => 'txt', 'filesize' => $filesize, 'filetime' => $filetime, 'isedit' => true);
                $f[] = $key;
            } elseif (preg_match("#\.(htm|html)#i", $file)) {
                $files[$key] = array('file' => $file, 'icon' => 'htm', 'filesize' => $filesize, 'filetime' => $filetime, 'isedit' => true);
                $f[] = $key;
            } elseif (preg_match("#\.(php)#i", $file)) {
                $files[$key] = array('file' => $file, 'icon' => 'php', 'filesize' => $filesize, 'filetime' => $filetime, 'isedit' => true);
                $f[] = $key;
            } elseif (preg_match("#\.(js)#i", $file)) {
                $files[$key] = array('file' => $file, 'icon' => 'js', 'filesize' => $filesize, 'filetime' => $filetime, 'isedit' => true);
                $f[] = $key;
            } elseif (preg_match("#\.(css)#i", $file)) {
                $files[$key] = array('file' => $file, 'icon' => 'css', 'filesize' => $filesize, 'filetime' => $filetime, 'isedit' => true);
                $f[] = $key;
            } else {
                $files[$key] = array('file' => $file, 'icon' => '', 'filesize' => $filesize, 'filetime' => $filetime, 'isedit' => false);
                $f[] = $key;
            }
        }
        $dh->close();
        array_multisort($d, SORT_ASC, SORT_STRING);
        array_multisort($f, SORT_ASC, SORT_STRING);
        $data = ['d' => $d, 'f' => $f, 'dirs' => $dirs, 'files' => $files, 'back' => $back, 'dirpath' => $dirpath];
        return self::output()->withCode(200)->withData($data);
    }

    public static function fileView(string $fileurl): OutputInterface
    {
        $res = self::fileCheck($fileurl);
        if ($res->getCode() != 200) {
            return $res;
        }
        $file = CSROOT . $fileurl;
        $data = [];
        $isedit = strpos($fileurl, '.');
        $data['dirname'] = $isedit ? str_replace('\\', '/', dirname($fileurl)) : $fileurl;
        $data['filename'] = $isedit ? basename($fileurl) : '';
        $data['extension'] = $isedit ? pathinfo($fileurl, PATHINFO_EXTENSION) : 'html';
        if ($data['extension'] == 'js') {
            $data['extension'] = 'javascript';
        } elseif ($data['extension'] == 'php') {
            $data['extension'] = 'php';
        } elseif ($data['extension'] == 'css') {
            $data['extension'] = 'css';
        } elseif ($data['extension'] == 'json') {
            $data['extension'] = 'json';
        } elseif ($data['extension'] == 'xml') {
            $data['extension'] = 'xml';
        } else {
            $data['extension'] = 'html';
        }
        $data['content'] = is_file($file) ? Str::htmlspecialchars(file_get_contents($file), 'en') : '';
        return self::output()->withCode(200)->withData($data);
    }

    /**
     * 文件添加编辑
     * @param $filename 文件名称
     * @param $dirname 文件地址
     * @param $content 文件内容
     * @param $type add添加，edit编辑
     * @return OutputInterface
     * @throws \SlimCMS\Error\TextException
     */
    public static function fileSave(string $filename, string $dirname, string $content, string $type = 'add'): OutputInterface
    {
        $res = self::fileCheck($dirname);
        if ($res->getCode() != 200) {
            return $res;
        }

        $file = CSROOT . $dirname . '/' . $filename;
        if ($type == 'add' && is_file($file)) {
            return self::output()->withCode(9100002);
        }
        file_put_contents($file, $content);
        $referer = Forms::url('?p=plugin/files/fileSave&fileurl=' . $dirname . '/' . $filename);
        return self::output()->withCode(200)->withReferer($referer);
    }

    /**
     * 删除文件
     *
     * @param unknown_type $fileurl
     * @return unknown
     */
    public static function delFile(string $fileurl): OutputInterface
    {
        $res = self::fileCheck($fileurl);
        if ($res->getCode() != 200) {
            return $res;
        }
        $filename = CSROOT . $fileurl;
        File::delFiles($filename);
        $referer = Forms::url('?p=plugin/files/fileList&dirpath=' . str_replace('\\', '/', dirname($fileurl)));
        return self::output()->withCode(200)->withReferer($referer);
    }

    /**
     * 创建文件夹
     * @param $dirpath
     * @param $dirname
     * @return OutputInterface
     * @throws \SlimCMS\Error\TextException
     */
    public static function createDir(string $dirpath, string $dirname): OutputInterface
    {
        if (empty($dirname)) {
            return self::output()->withCode(21003);
        }
        $res = self::fileCheck($dirpath);
        if ($res->getCode() != 200) {
            return $res;
        }
        $dir = CSROOT . $dirpath . '/' . $dirname;
        if (is_dir($dir)) {
            return self::output()->withCode(9100003);
        }
        File::mkdir(CSROOT . $dirpath . '/' . $dirname);
        $referer = Forms::url('?p=plugin/files/fileList&dirpath=' . $dirpath . '/' . $dirname);
        return self::output()->withCode(200)->withReferer($referer);
    }

    /**
     * 重命名
     * @param string $fileurl
     * @param string $newfilename
     * @return OutputInterface
     * @throws \SlimCMS\Error\TextException
     */
    public static function rename(string $fileurl, string $newfilename): OutputInterface
    {
        if (empty($newfilename)) {
            return self::output()->withCode(21003);
        }
        $res = self::fileCheck($fileurl);
        if ($res->getCode() != 200) {
            return $res;
        }
        $dirname = trim(str_replace(['\\', '.'], ['/', '/'], dirname($fileurl)), '/') . '/';

        $oldpath = CSROOT . $fileurl;
        $newpath = CSROOT . $dirname . $newfilename;
        if (is_file($newpath)) {
            return self::output()->withCode(9100004);
        }
        if (!is_writable($oldpath)) {
            return self::output()->withCode(9100005);
        }
        rename($oldpath, $newpath);
        $referer = Forms::url('?p=plugin/files/fileList&dirpath=' . $dirname);
        return self::output()->withCode(200)->withReferer($referer);
    }

    /**
     * 移动文件
     * @param string $fileurl 文件地址
     * @param string $newpath 移动到新地址
     * @return OutputInterface
     * @throws \SlimCMS\Error\TextException
     */
    public static function remove(string $fileurl, string $newpath): OutputInterface
    {
        if (empty($newpath)) {
            return self::output()->withCode(21003);
        }
        $res = self::fileCheck($fileurl);
        if ($res->getCode() != 200) {
            return $res;
        }
        $oldfile = CSROOT . $fileurl;
        if (!is_file($oldfile)) {
            return self::output()->withCode(9100006);
        }
        $dirname = dirname($fileurl);
        $filename = basename($fileurl);

        if ($newpath[0] != '/') {
            $newpath = $dirname . '/' . $newpath;
        }
        File::mkdir(CSROOT . $newpath);
        $reapath = realpath(CSROOT . $newpath);
        if (
            $reapath === false || (
                strpos($reapath, realpath(CSROOT . 'app/')) === false &&
                strpos($reapath, realpath(CSROOT . 'template/')) === false &&
                strpos($reapath, realpath(CSROOT . 'public/')) === false
            )
        ) {
            return self::output()->withCode(21019);
        }
        $newfile = $reapath . '/' . $filename;
        copy($oldfile, $newfile);
        unlink($oldfile);
        $referer = Forms::url('?p=plugin/files/fileList&dirpath=' . str_replace('\\', '/', $newpath));
        return self::output()->withCode(200)->withReferer($referer);
    }

    /**
     * 解压ZIP文件
     * @param $zip
     * @param $dir
     * @return OutputInterface
     * @throws \SlimCMS\Error\TextException
     */
    public static function zipUnpack(string $zip, string $dir): OutputInterface
    {
        if (empty($zip)) {
            return self::output()->withCode(21003);
        }
        $res = self::fileCheck($dir);
        if ($res->getCode() != 200) {
            return $res;
        }
        $res = Zip::unpack(CSPUBLIC . $zip, CSROOT . $dir);
        if ($res === true) {
            unlink(CSPUBLIC . $zip);
        }
        $referer = Forms::url('?p=plugin/files/fileList&dirpath=' . str_replace('\\', '/', $dir));
        return self::output()->withCode(200)->withReferer($referer);
    }
}
