<?php
/**
 * 文件管理插件控制类
 * @author zhucy
 */

declare(strict_types=1);

namespace App\Control\admincp\plugin;

use App\Control\admincp\AdmincpControl;
use App\Core\Forms;
use App\Model\plugin\files\FilesModel;
use App\Model\plugin\PluginModel;
use SlimCMS\Core\Request;
use SlimCMS\Core\Response;
use SlimCMS\Error\TextException;
use SlimCMS\Helper\Str;

class FilesControl extends AdmincpControl
{
    private static $identifier = 'files';

    public function __construct(Request $request, Response $response)
    {
        parent::__construct($request, $response);
        $res = PluginModel::getConfig(self::$identifier);
        if ($res->getCode() != 200) {
            throw new TextException($res->getCode());
        }
    }

    private function fileFilter($file)
    {
        $file = str_replace(['..', '\\'], ['', '/'], $file);
        return preg_replace("#/{1,}#", '/', $file);
    }

    /**
     * 文件列表
     * @return array|\Psr\Http\Message\ResponseInterface
     */
    public function fileList()
    {
        $this->checkAllow();
        $dirpath = $this->fileFilter(self::inputString('dirpath'));
        $res = FilesModel::fileList($dirpath);
        return $this->view($res);
    }

    /**
     * 文件添加编辑
     * @return array|\Psr\Http\Message\ResponseInterface
     * @throws TextException
     */
    public function fileSave()
    {
        $this->checkAllow();
        $formhash = self::input('formhash');
        if ($formhash) {
            $res = Forms::submitCheck($formhash);
            if ($res->getCode() != 200) {
                return $this->directTo($res);
            }
            $str = Str::htmlspecialchars(aval($_POST, 'str'), 'de');
            $filename = self::inputString('filename');
            $dirname = $this->fileFilter(self::inputString('dirname'));
            $type = self::inputString('type');
            $res = FilesModel::fileSave($filename, $dirname, $str, $type);
            return $this->directTo($res);
        }

        $fileurl = $this->fileFilter(self::inputString('fileurl'));
        $res = FilesModel::fileView($fileurl);
        if ($res->getCode() != 200) {
            return $this->directTo($res);
        }
        return $this->view($res);
    }

    /**
     * 删除文件
     * @return array|\Psr\Http\Message\ResponseInterface
     */
    public function delFile()
    {
        $this->checkAllow();
        $fileurl = $this->fileFilter(self::inputString('fileurl'));
        $res = FilesModel::delFile($fileurl);
        return $this->directTo($res);
    }

    /**
     * 创建文件夹
     * @return array|\Psr\Http\Message\ResponseInterface
     * @throws TextException
     */
    public function createDir()
    {
        $this->checkAllow();
        $dirpath = $this->fileFilter(self::inputString('dirpath'));
        $formhash = self::inputString('formhash');
        if ($formhash) {
            $res = Forms::submitCheck($formhash);
            if ($res->getCode() != 200) {
                return $this->directTo($res);
            }
            $dirname = $this->fileFilter(self::inputString('dirname'));
            $res = FilesModel::createDir($dirpath, $dirname);
            return $this->directTo($res);
        }
        $data = [];
        $data['dirpath'] = $dirpath;
        return $this->view(self::$output->withData($data));
    }

    /**
     * 重命名
     * @return array|\Psr\Http\Message\ResponseInterface
     * @throws TextException
     */
    public function rename()
    {
        $this->checkAllow();
        $fileurl = $this->fileFilter(self::inputString('fileurl'));
        $formhash = self::inputString('formhash');
        if ($formhash) {
            $res = Forms::submitCheck($formhash);
            if ($res->getCode() != 200) {
                return $this->directTo($res);
            }
            $newfilename = self::inputString('newfilename');
            $res = FilesModel::rename($fileurl, $newfilename);
            return $this->directTo($res);
        }
        $data = [];
        $data['dirname'] = str_replace(['\\', '.'], ['/', '/'], dirname($fileurl));
        $data['filename'] = basename($fileurl);
        return $this->view(self::$output->withData($data));
    }

    /**
     * 文件移动
     * @return array|\Psr\Http\Message\ResponseInterface
     * @throws TextException
     */
    public function remove()
    {
        $this->checkAllow();
        $fileurl = $this->fileFilter(self::inputString('fileurl'));
        $formhash = self::inputString('formhash');
        if ($formhash) {
            $res = Forms::submitCheck($formhash);
            if ($res->getCode() != 200) {
                return $this->directTo($res);
            }
            $newpath = self::inputString('newpath');
            $res = FilesModel::remove($fileurl, $newpath);
            return $this->directTo($res);
        }
        $data = [];
        $data['dirname'] = str_replace('\\', '/', dirname($fileurl));
        $data['filename'] = basename($fileurl);
        return $this->view(self::$output->withData($data));
    }

    /**
     * 上传单个文件
     * @return array|\Psr\Http\Message\ResponseInterface
     */
    public function upload()
    {
        $this->checkAllow();
        $dirpath = $this->fileFilter(self::inputString('dirpath'));
        $formhash = self::inputString('formhash');
        if ($formhash) {
            $res = Forms::submitCheck($formhash);
            if ($res->getCode() != 200) {
                return $this->directTo($res);
            }

            $j = 0;
            $replace = self::inputInt('replace');
            for ($i = 1; $i <= 50; $i++) {
                $upfile = "upfile" . $i;
                if (empty($_FILES[$upfile]['tmp_name']) || !is_uploaded_file($_FILES[$upfile]['tmp_name'])) {
                    continue;
                }
                $fileurl = CSROOT . $dirpath . '/' . $_FILES[$upfile]['name'];
                if ($replace == 1 && is_file($fileurl)) {
                    unlink($fileurl);
                }
                if (!is_file($fileurl)) {
                    move_uploaded_file($_FILES[$upfile]['tmp_name'], $fileurl);
                    $j++;
                }
                is_file($_FILES[$upfile]['tmp_name']) && @unlink($_FILES[$upfile]['tmp_name']);
            }
            $referer = Forms::url('?p=plugin/files/fileList&dirpath=' . $dirpath);
            $res = self::$output->withCode(200, "成功上传 $j 个文件到: " . $dirpath)->withReferer($referer);
            return $this->directTo($res);
        }
        $data = [];
        $data['dirpath'] = $dirpath;
        return $this->view(self::$output->withData($data));
    }

    /**
     * 通过ZIP压缩包上传
     * @return array|\Psr\Http\Message\ResponseInterface
     */
    public function zipUnpack()
    {
        $this->checkAllow();
        $dirpath = $this->fileFilter(self::inputString('dirpath'));
        $formhash = self::inputString('formhash');
        if ($formhash) {
            $res = Forms::submitCheck($formhash);
            if ($res->getCode() != 200) {
                return $this->directTo($res);
            }
            $zip = self::inputString('zip');
            $res = FilesModel::zipUnpack($zip, $dirpath);
            return $this->directTo($res);
        }
        $data = [];
        $data['dirpath'] = $dirpath;
        return $this->view(self::$output->withData($data));
    }
}
