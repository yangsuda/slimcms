
DROP TABLE IF EXISTS `#@#api_applog`;
CREATE TABLE `#@#api_applog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ischeck` tinyint(1) NOT NULL DEFAULT '2' COMMENT '是否审核(1=已审核，2=未审核)',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `ip` varchar(20) NOT NULL DEFAULT '' COMMENT '创建IP',
  `appid` varchar(250) NOT NULL DEFAULT '' COMMENT '应用ID',
  `method` varchar(250) NOT NULL DEFAULT '' COMMENT '调用方式',
  `query` varchar(250) NOT NULL DEFAULT '' COMMENT '请求地址',
  `route` varchar(250) NOT NULL DEFAULT '' COMMENT '路由地址',
  `postinfo` text NOT NULL COMMENT 'POST信息',
  PRIMARY KEY (`id`),
  KEY `appid` (`appid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应用调用日志';

DROP TABLE IF EXISTS `#@#api_apps`;
CREATE TABLE `#@#api_apps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ischeck` tinyint(1) NOT NULL DEFAULT '2' COMMENT '是否审核(1=已审核，2=未审核)',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `ip` varchar(20) NOT NULL DEFAULT '' COMMENT '创建IP',
  `appid` varchar(50) NOT NULL DEFAULT '' COMMENT '应用id',
  `appsecret` varchar(50) NOT NULL DEFAULT '' COMMENT '应用密码',
  `appname` varchar(250) NOT NULL DEFAULT '' COMMENT '应用名称',
  `appapi` varchar(250) NOT NULL DEFAULT '' COMMENT '允许请求的API接口(api_list={&quot;name&quot;:&quot;apiname&quot;,&quot;value&quot;:&quot;id&quot;})',
  `lasttime` int(11) NOT NULL DEFAULT '0' COMMENT '上次调用时间',
  `lastip` varchar(250) NOT NULL DEFAULT '' COMMENT '上次调用IP',
  `accesstoken` varchar(250) NOT NULL DEFAULT '' COMMENT 'accessToken',
  PRIMARY KEY (`id`),
  KEY `appid` (`appid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应用管理';

DROP TABLE IF EXISTS `#@#api_group`;
CREATE TABLE `#@#api_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ischeck` tinyint(1) NOT NULL DEFAULT '2' COMMENT '是否审核(1=已审核，2=未审核)',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `ip` varchar(20) NOT NULL DEFAULT '' COMMENT '创建IP',
  `groupname` varchar(250) NOT NULL DEFAULT '' COMMENT '组名',
  `formid` int(11) NOT NULL DEFAULT '0' COMMENT '所属表单ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='接口分组';

INSERT INTO `#@#api_group` VALUES (null, '2', '1631945920', '', '默认分组', '0');

DROP TABLE IF EXISTS `#@#api_list`;
CREATE TABLE `#@#api_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ischeck` tinyint(1) NOT NULL DEFAULT '2' COMMENT '是否审核(1=已审核，2=未审核)',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `ip` varchar(20) NOT NULL DEFAULT '' COMMENT '创建IP',
  `apiname` varchar(50) NOT NULL DEFAULT '' COMMENT '接口名称',
  `path` varchar(250) NOT NULL DEFAULT '' COMMENT '接口路由地址',
  `groupid` tinyint(2) NOT NULL DEFAULT '1' COMMENT '接口分组(api_group={&quot;name&quot;:&quot;groupname&quot;,&quot;value&quot;:&quot;id&quot;})',
  `method` tinyint(1) NOT NULL DEFAULT '0' COMMENT '请求方式(1=POST,2=GET)',
  `formid` int(10) NOT NULL DEFAULT '0' COMMENT '所属表单(forms={&quot;condition&quot;:&quot;openapi&lt;&gt;&#039;&#039;&quot;,&quot;name&quot;:&quot;name&quot;,&quot;value&quot;:&quot;id&quot;})',
  `openapiid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '开放前端接口ID(1=列表,2=展示,3=添加修改,4=删除,5=导出,6=表单结构,7=审核,8=统计)',
  `result` text NOT NULL COMMENT '返回结果',
  `intro` text NOT NULL COMMENT '接口说明',
  `identifier` varchar(250) NOT NULL COMMENT '接口唯一标识符',
  `tokencheck` tinyint(1) NOT NULL DEFAULT '1' COMMENT '开启AccessToken验证(1=是,-1=否)',
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`),
  KEY `formid` (`formid`),
  KEY `identifier` (`identifier`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='接口管理';

INSERT INTO `#@#api_list` VALUES
(1, '1', '1634527066', '', '获取accessToken', 'plugin/api/getAccessToken', '1', '2', '0', '0', '{\r\n    \"code\": 200,\r\n    \"msg\": \"操作成功\",\r\n    \"data\": {\r\n        \"accessToken\": \"abiLJ0CuB3Nn8v6PqZwitWsLrzr1emBiX14WtN3jMMJgXhVwzYUGJBatXsuS17kG2Z3TsYnc2V2djvTPDC3V4A==\"\r\n    }\r\n}', '如果后台开户了accessToken校验，获取accessToken是调用API接口的第一步，相当于创建了一个登录凭证，其它的业务API接口，都需要依赖于accessToken来鉴权调用者身份。\r\naccessToken的有效期后台系统设置里设置，默认7200秒（2小时），过期后，开发者应实现accessToken失效时重新获取的逻辑。', 'de38cbccf4264e46721666e2b0d14363', '-1'),
(2, '1', '1634534347', '', '获取OPENID', 'plugin/api/getOpenid', '1', '2', '0', '0', '{\r\n    \"code\": 200,\r\n    \"msg\": \"操作成功\",\r\n    \"data\": {\r\n         \"openid\":\"oGkXvstoDtZiRmHtOtzG7ek6ywzg\",\r\n         \"session_key\":\"kJtdi6RF+Dv67QkbLlPGjw==\",\r\n      },\r\n}', '调用此接口前，请先确保在系统设置中配置了appid和appsecret，否则会报21003', 'b23b14317a78c462ebdca767648823aa', '-1'),
(3, '1', '1634534913', '', '解密用户信息', 'plugin/api/decryptData', '1', '2', '0', '0', '{\r\n    \"code\": 200,\r\n    \"msg\": \"操作成功\",\r\n    \"data\": {\r\n         \"openid\":\"oGkXvstoDtZiRmHtOtzG7ek6ywzg\",\r\n         \"nickname\":\"slimCMS\",\r\n         \"headimgurl\":\"https://wx.qlogo.cn/mmopen/vi_32/IPe7xc4hO8nIIW54z75QEpKD3Tcu9HCKfiaU4N8ERicOuicIJHt0iaqfUpmPt3lxdaW1Kg85KibRVbUpoxpH3wXa0y1/132\",\r\n    }\r\n}', '调用此接口前，请先确保在系统设置中配置了appid和appsecret，否则会报21003', '8f432d20e1924d05547c687ed6392d8e', '1'),
(4, '1', '1634535704', '', '上传图片', 'plugin/api/uploadFile', '1', '1', '0', '0', '{\r\n    \"code\": 200,\r\n    \"msg\": \"操作成功\",\r\n      \"data\": {\r\n         \"pic\":\"/uploads/2021/09/497b3f3fd9ba6155103520cde098849138.jpg\"\r\n    }\r\n}', '', '3f783c809df0f7f2c05746c4985f4833', '1'),
(5, '1', '1634536149', '', '生成小程序二维码', 'plugin/api/qrcode', '1', '2', '0', '0', '', '返回二维码图片URL', 'e4e7cf90702b5c0172dd800496cbc8bf', '1'),
(6, '1', '1634630585', '', '发送小程序订阅消息', 'plugin/api/sendTemplateMessage', '1', '2', '0', '0', '{\r\n    \"code\": 200,\r\n    \"msg\": \"操作成功\",\r\n    \"data\": {},\r\n}', '', '1a16e7ffeceaae845c11496d6a4f3e98', '1'),
(7, '1', '1634631045', '', '获取公众号CODE', 'plugin/api/getCode', '1', '2', '0', '0', '', '跳转到回调地址&#040;redirect传的URL&#041;并带上code值', 'e98754d74e44ad83e9cad6cd7ae23fed', '-1'),
(8, '1', '1634631554', '', '获取微信用户信息', 'plugin/api/getUserInfo', '1', '2', '0', '0', '{\r\n    \"code\": 200,\r\n    \"msg\": \"操作成功\",\r\n    \"data\": {\r\n        \"wxuser\":{\r\n          \"openid\":\"oGkXvstoDtZiRmHtOtzG7ek6ywzg\",\r\n          \"nickname\":\"test\",\r\n          \"sex\": 1,\r\n          \"province\":\"jiangsu\",\r\n          \"city\":\"suzhou\",\r\n          \"country\":\"CN\",\r\n          \"headimgurl\":\"https://thirdwx.qlogo.cn/mmopen/g3MonUZtNHkdmzicIlibx6iaFqAc56vxLSUfpb6n5WKSYVY0ChQKkiaJSgQ1dZuTOgvLLrhJbERQQ4eMsv84eavHiaiceqxibJxCfHe/46\",\r\n          \"privilege\":[\"PRIVILEGE1\",\"PRIVILEGE2\"],\r\n          \"unionid\":\"o6_bmasdasdsad6_2sgVt7hMZOPfL\"\r\n        }\r\n    }\r\n}', '获取公众号CODE时如果传的是base，获取的是基本信息，只有openid等参数，如果是userinfo，获取的是用户微信昵称、头像等更多信息', 'a664bfa7bcf7eb72cc07ef2dd0a90b48', '-1'),
(9, '1', '1634632504', '', '生成微信分享签名', 'plugin/api/wxJsapiConfig', '1', '2', '0', '0', '{\r\n    \"code\": 200,\r\n    \"msg\": \"操作成功\",\r\n    \"data\": {},\r\n}', '', 'fb4190b0daefba681125165faa7fb63b', '-1');

DROP TABLE IF EXISTS `#@#api_request`;
CREATE TABLE `#@#api_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ischeck` tinyint(1) NOT NULL DEFAULT '2' COMMENT '是否审核(1=已审核，2=未审核)',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `ip` varchar(20) NOT NULL DEFAULT '' COMMENT '创建IP',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '字段名称',
  `types` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型(1=string,2=int,3=array,4=float,5=date,6=URL,7=tel,8=price)',
  `ismust` tinyint(1) NOT NULL DEFAULT '-1' COMMENT '是否必填(-1=不必填,1=必填)',
  `intro` varchar(250) NOT NULL DEFAULT '' COMMENT '说明',
  `apiid` int(10) NOT NULL DEFAULT '0' COMMENT '所属接口(apilist={&quot;name&quot;:&quot;apiname&quot;,&quot;value&quot;:&quot;id&quot;})',
  `default` varchar(250) NOT NULL DEFAULT '' COMMENT '默认值',
  `fieldid` int(10) NOT NULL COMMENT '字段ID',
  PRIMARY KEY (`id`),
  KEY `fieldid` (`fieldid`),
  KEY `apiid` (`apiid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='接口请求参数';

INSERT INTO `#@#api_request` VALUES
(null, '2', '1634532944', '', 'appid', '1', '1', '应用ID', '1', '', '0'),
(null, '2', '1634532964', '', 'appsecret', '1', '1', '应用secret', '1', '', '0'),
(null, '2', '1634534706', '', 'code', '1', '1', '微信返回的CODE', '2', '', '0'),
(null, '2', '1634535258', '', 'sessionkey', '1', '1', 'sessionkey值', '3', '', '0'),
(null, '2', '1634535279', '', 'encrypteddata', '1', '1', 'encrypteddata值', '3', '', '0'),
(null, '2', '1634535293', '', 'iv', '1', '1', 'iv值', '3', '', '0'),
(null, '2', '1634535951', '', 'name', '1', '1', '上传图片', '4', '', '0'),
(null, '2', '1634536343', '', 'scene', '1', '1', '只能字母或数据', '5', '', '0'),
(null, '2', '1634536398', '', 'width', '2', '-1', '宽度', '5', '430', '0'),
(null, '2', '1634536436', '', 'page', '1', '-1', '小程序跳转地址', '5', '', '0'),
(null, '2', '1634630854', '', 'touser', '1', '1', '', '6', '接收者的openid', '0'),
(null, '2', '1634630876', '', 'template_id', '1', '1', '订阅模板id', '6', '', '0'),
(null, '2', '1634630908', '', 'data', '1', '1', '模板内容，格式形如{&quot;key1&quot;:&quot;any&quot;,&quot;key2&quot;:&quot;any&quot;}', '6', '', '0'),
(null, '2', '1634630921', '', 'page', '1', '-1', '跳转页面', '6', '', '0'),
(null, '2', '1634631290', '', 'scope', '1', '-1', '基本信息固定值:base，详细信息固定值:userinfo', '7', 'userinfo', '0'),
(null, '2', '1634631329', '', 'redirect', '6', '1', '跳转地址', '7', '', '0'),
(null, '2', '1634632082', '', 'code', '1', '1', '通过getCode接口获取的code值', '8', '', '0'),
(null, '2', '1634632589', '', 'url', '6', '1', '链接地址', '9', '', '0');

DROP TABLE IF EXISTS `#@#api_response`;
CREATE TABLE `#@#api_response` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ischeck` tinyint(1) NOT NULL DEFAULT '2' COMMENT '是否审核(1=已审核，2=未审核)',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `ip` varchar(20) NOT NULL DEFAULT '' COMMENT '创建IP',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '字段名称',
  `types` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型(1=string,2=int,3=array,4=float,5=date,6=URL,7=tel,8=price)',
  `intro` varchar(250) NOT NULL DEFAULT '' COMMENT '说明',
  `apiid` int(10) NOT NULL DEFAULT '0' COMMENT '所属接口(apilist={&quot;name&quot;:&quot;apiname&quot;,&quot;value&quot;:&quot;id&quot;})',
  `fieldid` int(10) NOT NULL COMMENT '字段ID',
  PRIMARY KEY (`id`),
  KEY `apiid` (`apiid`),
  KEY `fieldid` (`fieldid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='接口返回参数';

INSERT INTO `#@#api_response` VALUES
(null, '2', '1634532797', '', 'accessToken', '1', '获取到的接口调用凭证', '1', '0'),
(null, '2', '1634534668', '', 'openid', '1', '微信openid', '2', '0'),
(null, '2', '1634534751', '', 'session_key', '1', 'session_key值', '2', '0'),
(null, '2', '1634535333', '', 'openid', '1', '微信openid', '3', '0'),
(null, '2', '1634535348', '', 'nickname', '1', '微信昵称', '3', '0'),
(null, '2', '1634535366', '', 'headimgurl', '6', '微信头像', '3', '0'),
(null, '2', '1634535997', '', 'pic', '1', '图片URL', '4', '0'),
(null, '2', '1634632118', '', 'openid', '1', '微信用户的唯一标识', '8', '0'),
(null, '2', '1634632131', '', 'nickname', '1', '用户昵称', '8', '0'),
(null, '2', '1634632147', '', 'sex', '2', '用户的性别，值为1时是男性，值为2时是女性，值为0时是未知', '8', '0'),
(null, '2', '1634632161', '', 'province', '1', '用户个人资料填写的省份', '8', '0'),
(null, '2', '1634632175', '', 'city', '1', '普通用户个人资料填写的城市', '8', '0'),
(null, '2', '1634632188', '', 'country', '1', '国家，如中国为CN', '8', '0'),
(null, '2', '1634632230', '', 'headimgurl', '6', '用户头像，最后一个数值代表正方形头像大小（有0、46、64、96、132数值可选，0代表640&#042;640正方形头像），用户没有头像时该项为空。若用户更换头像，原有头像URL将失效。', '84', '0'),
(null, '2', '1634632247', '', 'privilege', '1', '用户特权信息，json 数组，如微信沃卡用户为（chinaunicom）', '8', '0'),
(null, '2', '1634632261', '', 'unionid', '1', '只有在用户将公众号绑定到微信开放平台帐号后，才会出现该字段。', '8', '0'),
(null, '2', '1634632832', '', 'appid', '1', '应用ID', '9', '0'),
(null, '2', '1634632878', '', 'ticket', '1', '微信jsapi_ticket', '9', '0'),
(null, '2', '1634632892', '', 'noncestr', '1', '随机数', '9', '0'),
(null, '2', '1634632906', '', 'timestamp', '2', '时间戳', '9', '0'),
(null, '2', '1634632920', '', 'url', '6', '链接地址', '9', '0'),
(null, '2', '1634632934', '', 'signature', '1', '生成的签名', '9', '0');

ALTER TABLE `#@#forms` ADD COLUMN `openapi` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '开放前端接口(1=列表,2=展示,3=添加修改,4=删除,5=导出,6=表单结构,7=审核,8=统计)';

INSERT INTO `#@#forms_fields` VALUES
(null, '开放前端接口', 'openapi', '1', 'checkbox', '42', '1', '1', '2', '2', '2', '2', '1', '1', '1', '', '0', '', '', '', '', 'a:8:{i:1;s:6:\"列表\";i:2;s:6:\"展示\";i:3;s:12:\"添加修改\";i:4;s:6:\"删除\";i:5;s:6:\"导出\";i:6;s:12:\"表单结构\";i:7;s:6:\"审核\";i:8;s:6:\"统计\";}', '', '', '', '1583886124', '1', '', '', 'varchar', '50.0000', '1', '3', '1', '');

INSERT INTO `#@#forms` (`id`,`name`,`table`,`export`,`cpcheck`,`isarchive`,`createtime`,`ischeck`,`cpadd`,`types`,`cpdel`) VALUES
(null, '接口管理', 'api_list', '2', '1', '2', '1631928913', '2', '1', 'fa fa-link bigfonts', '1'),
(null, '接口分组', 'api_group', '2', '2', '2', '1631945559', '2', '1', 'fa fa-link bigfonts', '1'),
(null, '接口请求参数', 'api_request', '2', '2', '2', '1632274311', '2', '1', 'fa fa-link bigfonts', '1'),
(null, '接口返回参数', 'api_response', '2', '2', '2', '1632274349', '2', '1', 'fa fa-link bigfonts', '1'),
(null, '应用管理', 'api_apps', '2', '1', '2', '1634273000', '2', '1', 'fa fa-link bigfonts', '1'),
(null, '应用调用日志', 'api_applog', '2', '2', '2', '1634287288', '2', '1', 'fa fa-link bigfonts', '1');

INSERT INTO `#@#forms_fields` VALUES
(null, '接口名称', 'apiname', '-1', 'text', '50', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1631934423', '2', '', '', 'varchar', '50.0000', '1', '3', '1', ''),
(null, '接口路由地址', 'path', '-1', 'text', '49', '1', '1', '2', '2', '2', '2', '2', '2', '1', '', '0', '如：“XXX?p=api/test”，接口路由地址为p参数值', '', '', '如:api/test', '', '', '', '', '1631934932', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '接口分组', 'groupid', '-1', 'select', '48', '1', '1', '2', '2', '1', '2', '2', '1', '1', '1', '0', '', '', '', '', 'a:1:{s:9:\"api_group\";s:73:\"{&quot;name&quot;:&quot;groupname&quot;,&quot;value&quot;:&quot;id&quot;}\";}', '', '', '', '1631935428', '2', '', '', 'tinyint', '2.0000', '1', '3', '1', ''),
(null, '请求方式', 'method', '-1', 'select', '47', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', 'a:2:{i:1;s:4:\"POST\";i:2;s:3:\"GET\";}', '', '', '', '1631946362', '2', '', '', 'tinyint', '1.0000', '1', '3', '1', ''),
(null, '所属表单', 'formid', '-1', 'select', '44', '1', '1', '2', '2', '1', '2', '2', '2', '1', '', '0', '', '', '', '', 'a:1:{s:5:\"forms\";s:130:\"{&quot;condition&quot;:&quot;openapi&lt;&gt;&#039;&#039;&quot;,&quot;name&quot;:&quot;name&quot;,&quot;value&quot;:&quot;id&quot;}\";}', '', '', '', '1632272296', '2', '', '', 'int', '10.0000', '1', '3', '1', ''),
(null, '开放前端接口ID', 'openapiid', '-1', 'select', '43', '1', '1', '2', '2', '2', '2', '2', '2', '1', '', '0', '', '', '', '', 'a:8:{i:1;s:6:\"列表\";i:2;s:6:\"展示\";i:3;s:12:\"添加修改\";i:4;s:6:\"删除\";i:5;s:6:\"导出\";i:6;s:12:\"表单结构\";i:7;s:6:\"审核\";i:8;s:6:\"统计\";}', '', '', '', '1632272507', '2', '', '', 'tinyint', '1.0000', '1', '3', '1', ''),
(null, '返回结果', 'result', '-1', 'multitext', '42', '1', '1', '2', '2', '2', '2', '2', '2', '1', '', '0', '', '', '', '', '', '', '', '', '1632820860', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '接口说明', 'intro', '-1', 'multitext', '41', '1', '1', '2', '2', '2', '2', '2', '2', '1', '', '0', '', '', '', '', '', '', '', '', '1634023987', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '接口唯一标识符', 'identifier', '-1', 'hidden', '40', '1', '1', '2', '1', '1', '2', '2', '2', '2', '', '0', '', '', '', '', '', '', '', '', '1634290209', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '开启AccessToken验证', 'tokencheck', '-1', 'radio', '39', '1', '1', '2', '2', '2', '2', '2', '2', '1', '1', '0', '', '', '', '', 'a:2:{i:1;s:3:\"是\";i:-1;s:3:\"否\";}', '', '', '', '1634533907', '2', '', '', 'tinyint', '1.0000', '1', '3', '1', ''),
(null, '组名', 'groupname', '-2', 'text', '50', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1631945783', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '所属表单ID', 'formid', '-2', 'int', '49', '1', '1', '2', '2', '2', '2', '2', '2', '1', '', '0', '用于同步表单开放前端接口', '', '', '', '', '', '', '', '1631945887', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '字段名称', 'name', '-3', 'text', '50', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1632293307', '2', '', '', 'varchar', '50.0000', '1', '3', '1', ''),
(null, '类型', 'types', '-3', 'select', '49', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', 'a:8:{i:1;s:6:\"string\";i:2;s:3:\"int\";i:3;s:5:\"array\";i:4;s:5:\"float\";i:5;s:4:\"date\";i:6;s:3:\"URL\";i:7;s:3:\"tel\";i:8;s:5:\"price\";}', '', '', '', '1632294023', '2', '', '', 'tinyint', '1.0000', '1', '3', '1', ''),
(null, '是否必填', 'ismust', '-3', 'radio', '48', '1', '1', '2', '2', '2', '2', '2', '1', '1', '-1', '0', '', '', '', '', 'a:2:{i:-1;s:9:\"不必填\";i:1;s:6:\"必填\";}', '', '', '', '1632294113', '2', '', '', 'tinyint', '1.0000', '1', '3', '1', ''),
(null, '说明', 'intro', '-3', 'text', '47', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1632294151', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '所属接口', 'apiid', '-3', 'select', '46', '1', '1', '2', '2', '1', '2', '2', '1', '1', '', '0', '', '', '', '', 'a:1:{s:8:\"api_list\";s:71:\"{&quot;name&quot;:&quot;apiname&quot;,&quot;value&quot;:&quot;id&quot;}\";}', '', '', '', '1632295178', '2', '', '', 'int', '10.0000', '1', '3', '1', ''),
(null, '默认值', 'default', '-3', 'text', '47', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1632296051', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '字段ID', 'fieldid', '-3', 'hidden', '46', '1', '1', '2', '2', '1', '2', '2', '2', '2', '', '0', '表单生成接口对应的字段ID，自定义接口忽略此参数', '', '', '', '', '', '', '', '1632731474', '2', '', '', 'int', '10.0000', '1', '3', '1', ''),
(null, '类型', 'types', '-4', 'select', '49', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', 'a:8:{i:1;s:6:\"string\";i:2;s:3:\"int\";i:3;s:5:\"array\";i:4;s:5:\"float\";i:5;s:4:\"date\";i:6;s:3:\"URL\";i:7;s:3:\"tel\";i:8;s:5:\"price\";}', '', '', '', '1632296550', '2', '', '', 'tinyint', '1.0000', '1', '3', '1', ''),
(null, '字段名称', 'name', '-4', 'text', '50', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1632296381', '2', '', '', 'varchar', '50.0000', '1', '3', '1', ''),
(null, '说明', 'intro', '-4', 'text', '48', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1632296651', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '所属接口', 'apiid', '-4', 'select', '47', '1', '1', '2', '2', '1', '2', '2', '1', '1', '', '0', '', '', '', '', 'a:1:{s:8:\"api_list\";s:71:\"{&quot;name&quot;:&quot;apiname&quot;,&quot;value&quot;:&quot;id&quot;}\";}', '', '', '', '1632296703', '2', '', '', 'int', '10.0000', '1', '3', '1', ''),
(null, '字段ID', 'fieldid', '-4', 'hidden', '46', '1', '1', '2', '2', '1', '2', '2', '2', '1', '', '0', '表单生成接口对应的字段ID，自定义接口忽略此参数', '', '', '', '', '', '', '', '1632821467', '2', '', '', 'int', '10.0000', '1', '3', '1', ''),
(null, '允许请求的API接口', 'appapi', '-5', 'checkbox', '47', '1', '1', '2', '2', '2', '2', '2', '2', '1', '', '0', '', '', '', '', 'a:1:{s:8:\"api_list\";s:71:\"{&quot;name&quot;:&quot;apiname&quot;,&quot;value&quot;:&quot;id&quot;}\";}', '', '', '', '1634273314', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '应用id', 'appid', '-5', 'readonly', '50', '1', '1', '2', '2', '1', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1634273109', '2', '', '', 'varchar', '50.0000', '1', '3', '1', ''),
(null, '应用密码', 'appsecret', '-5', 'readonly', '49', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1634273150', '2', '', '', 'varchar', '50.0000', '1', '3', '1', ''),
(null, '应用名称', 'appname', '-5', 'text', '48', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1634273178', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '上次调用时间', 'lasttime', '-5', 'datetime', '46', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1634285675', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '上次调用IP', 'lastip', '-5', 'text', '45', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1634285706', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, 'accessToken', 'accesstoken', '-5', 'text', '44', '1', '1', '2', '2', '2', '2', '2', '2', '1', '', '0', '', '', '', '', '', '', '', '', '1634288716', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '应用ID', 'appid', '-6', 'text', '50', '1', '1', '2', '2', '1', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1634287354', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '调用方式', 'method', '-6', 'text', '49', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1634287409', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '请求地址', 'query', '-6', 'text', '48', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1634287496', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, '路由地址', 'route', '-6', 'text', '47', '1', '1', '2', '2', '2', '2', '2', '1', '1', '', '0', '', '', '', '', '', '', '', '', '1634287519', '2', '', '', '', '0.0000', '1', '3', '1', ''),
(null, 'POST信息', 'postinfo', '-6', 'multitext', '46', '1', '1', '2', '2', '2', '2', '2', '2', '1', '', '0', '', '', '', '', '', '', '', '', '1634287535', '2', '', '', '', '0.0000', '1', '3', '1', '');
