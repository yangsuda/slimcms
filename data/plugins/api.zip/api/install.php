<?php
return [
    'tables' => [
        -1 => 'api_list',
        -2 => 'api_group',
        -3 => 'api_request',
        -4 => 'api_response',
        -5 => 'api_apps',
        -6 => 'api_applog'
    ],
    'install' => function () {
        $rules = self::t('forms_fields')->withWhere(2)->fetch('rules');
        $rules = unserialize($rules);
        $rules['fa fa-link bigfonts'] = '接口';
        self::t('forms_fields')->withWhere(2)->update(['rules' => serialize($rules)]);
        return self::$output->withCode(200);
    },
    'unstall' => function () {
        $rules = self::t('forms_fields')->withWhere(2)->fetch('rules');
        $rules = unserialize($rules);
        unset($rules['fa fa-link bigfonts']);
        self::t('forms_fields')->withWhere(2)->update(['rules' => serialize($rules)]);

        $db = self::t()->db();
        $tableName = self::$setting['db']['tablepre'] . 'forms';
        $db->query('ALTER TABLE `' . $tableName . '` DROP COLUMN `openapi`');

        self::t('forms_fields')->withWhere(['formid' => 1, 'identifier' => 'openapi'])->delete();
        return self::$output->withCode(200);
    },
    'openSwitch' => function ($tables, $switch = 1) {
        foreach ($tables as $v) {
            if ($switch == -1) {
                self::t('forms')->withWhere(['table' => $v])->update(['ischeck' => 2]);
            } else {
                if (in_array($v, ['api_list', 'api_group', 'api_apps', 'api_applog'])) {
                    self::t('forms')->withWhere(['table' => $v])->update(['ischeck' => 1]);
                }
            }
        }
        return self::$output->withCode(200);
    },
];
