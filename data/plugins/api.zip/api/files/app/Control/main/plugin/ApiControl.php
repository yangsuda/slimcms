<?php
/**
 * 接口插件控制类
 */
declare(strict_types=1);

namespace App\Control\main\plugin;

use App\Core\Forms;
use App\Model\plugin\api\WxModel;
use App\Model\plugin\PluginModel;
use App\Model\plugin\api\ApiModel;
use App\Model\plugin\api\AppsModel;
use SlimCMS\Abstracts\ControlAbstract;
use slimCMS\Core\Request;
use slimCMS\Core\Response;
use App\Core\Wxxcx;
use SlimCMS\Error\TextException;
use SlimCMS\Helper\Crypt;
use SlimCMS\Interfaces\OutputInterface;


class ApiControl extends ControlAbstract
{
    public function __construct(Request $request, Response $response)
    {
        parent::__construct($request, $response);
        $res = PluginModel::getConfig('api');
        if ($res->getCode() != 200) {
            throw new TextException($res->getCode());
        }
        self::$config['plugin'] = $res->getData()['config'];
        $this->headNoCache();
    }

    private static function output(): OutputInterface
    {
        return ApiModel::output();
    }

    /**
     * 请求方式测试
     * @param $method
     * @return array|\Psr\Http\Message\ResponseInterface
     */
    private function requestCheck($method)
    {
        $server = self::$request->getRequest()->getServerParams();
        if ($server['REQUEST_METHOD'] != $method) {
            throw new TextException(21063);
        }
    }

    /**
     * 头部中设置不缓存数据
     */
    private function headNoCache()
    {
        self::$response->getResponse()
            ->withHeader('Pragma', 'no-cache')
            ->withHeader('Cache-Control', 'no-cache')
            ->withHeader('Expires', '0');
    }

    /**
     * 权限检测
     * @return OutputInterface
     */
    private static function purviewCheck(...$identifier): OutputInterface
    {
        //验证请求来路
        if (!empty(self::$config['plugin']['refererWhite'])) {
            $arr = array_map('trim', explode("\n", self::$config['plugin']['refererWhite']));
            $str = str_replace('/', '\/', implode('|', $arr));
            if (empty($_SERVER['HTTP_REFERER']) || !preg_match('/^(' . $str . ')/i', $_SERVER['HTTP_REFERER'])) {
                return self::output()->withCode(21048);
            }
        }
        //token校验
        if (!empty(self::$config['plugin']['tokenCheck'])) {
            $accessToken = self::inputString('accessToken');
            $res = AppsModel::checkAccessToken($accessToken, $identifier);
            if ($res->getCode() != 200) {
                return $res;
            }
        } else {
            //如果未开启token校验，则只通过appid校验，防止外部知道接口地址后无限制的调用
            $appid = self::inputString('appid');
            $res = AppsModel::checkAppid($appid, $identifier);
            if ($res->getCode() != 200) {
                return $res;
            }
        }
        return self::output()->withCode(200);
    }

    /**
     * 接口列表
     * @return array|\Psr\Http\Message\ResponseInterface
     */
    public function doc()
    {
        isset($_SESSION) ? '' : session_start();
        $docAuth = (string)aval($_SESSION, 'docAuth');
        $appid = (string)Crypt::decrypt($docAuth);
        if (empty(self::$config['plugin']['tokenCheck']) || !empty($appid)) {
            $identifier = self::inputString('identifier') ?: 'de38cbccf4264e46721666e2b0d14363';
            self::$output = AppsModel::apiList($appid)->withData(['identifier' => $identifier, 'appid' => $appid, 'config' => self::$config['plugin']]);
            if ($identifier) {
                self::$output = AppsModel::apiView($identifier);
                $data = self::$output->getData();
                if (empty($data['row'])) {
                    return self::$response->getResponse()
                        ->withHeader('location', self::url('?p=plugin/api/doc'));
                }
            }
            return $this->view(self::$output);
        } else {
            return self::$response->getResponse()->withHeader('location', self::url('?p=plugin/api/docLogin'));
        }
    }

    /**
     * 接口文档查看登陆
     * @return array|\Psr\Http\Message\ResponseInterface
     * @throws TextException
     */
    public function docLogin()
    {
        $formhash = self::input('formhash');
        if ($formhash) {
            $res = Forms::submitCheck($formhash);
            if ($res->getCode() != 200) {
                return $this->response($res);
            }
            $appid = self::inputString('appid');
            $res = AppsModel::docLogin($appid);
            if ($res->getCode() == 200) {
                isset($_SESSION) ? '' : session_start();
                $_SESSION['docAuth'] = Crypt::encrypt($appid);
                $res = $res->withReferer(self::url('?p=plugin/api/doc'));
            }
            return $this->response($res);
        }
        return $this->view(self::$output);
    }

    /**
     * 退出
     * @return array
     */
    public function docLogout()
    {
        isset($_SESSION) ? '' : session_start();
        unset($_SESSION['docAuth']);
        $output = self::$output->withCode(200, 21047)->withReferer(self::url('?p=plugin/api/docLogin'));
        return self::directTo($output);
    }

    /**
     * 接口搜索
     * @return array|\Psr\Http\Message\ResponseInterface
     * @throws TextException
     */
    public function docSearch()
    {
        isset($_SESSION) ? '' : session_start();
        $docAuth = (string)aval($_SESSION, 'docAuth');
        $appid = (string)Crypt::decrypt($docAuth);
        if (empty(self::$config['plugin']['tokenCheck']) || !empty($appid)) {
            $words = self::inputString('words');
            self::$output = AppsModel::apiList($appid)->withData(['appid' => $appid]);
            if ($words) {
                self::$output = AppsModel::apiSearch($words);
            }
            return $this->view(self::$output);
        } else {
            return self::$response->getResponse()->withHeader('location', self::url('?p=plugin/api/docLogin'));
        }
    }

    /**
     * 错误代码
     * @return array|\Psr\Http\Message\ResponseInterface
     */
    public function errCode()
    {
        isset($_SESSION) ? '' : session_start();
        $docAuth = (string)aval($_SESSION, 'docAuth');
        $appid = Crypt::decrypt($docAuth);
        if (empty(self::$config['plugin']['tokenCheck']) || !empty($appid)) {
            self::$output = AppsModel::apiList($appid)->withData(['appid' => $appid, 'prompts' => self::$output->prompts()]);
            return $this->view(self::$output);
        } else {
            return self::$response->getResponse()->withHeader('location', self::url('?p=plugin/api/docLogin'));
        }
    }

    /**
     * 获取accessToken
     * @return OutputInterface
     * @throws \SlimCMS\Error\TextException
     */
    public function getAccessToken()
    {
        $this->requestCheck('GET');
        if (empty(self::$config['plugin']['tokenCheck'])) {
            $res = self::output()->withCode(9000004);
            return $this->json($res);
        }
        $appid = self::inputString('appid');
        $appsecret = self::inputString('appsecret');
        $res = AppsModel::getAccessToken($appid, $appsecret);
        return $this->json($res);
    }

    /**
     * 数据列表页
     * @return array|\Psr\Http\Message\ResponseInterface
     * @throws \SlimCMS\Error\TextException
     */
    public function dataList()
    {
        $this->requestCheck('GET');
        $param = self::input(['fid' => 'int', 'page' => 'int', 'pagesize' => 'int', 'order' => 'string', 'by' => 'string', 'ischeck' => 'int']);
        if (empty($param['fid'])) {
            return $this->json(self::output()->withCode(21002));
        }
        $res = self::purviewCheck('plugin/api/' . __FUNCTION__, $param['fid'], 1);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $param['inlistField'] = 'inlist';
        aval($param, 'order') != 'rand&#040;&#041;' && $param['cacheTime'] = 60;
        $res = Forms::dataList($param);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $data = $res->getData();
        unset($data['form'], $data['where'], $data['currenturl'], $data['get'], $data['tags'], $data['fid'], $data['by']);
        $res = self::output()->withCode(200)->withData($data);
        return $this->json($res);
    }

    /**
     * 数据统计
     * @return array|\Psr\Http\Message\ResponseInterface
     * @throws \SlimCMS\Error\TextException
     */
    public function dataCount()
    {
        $this->requestCheck('GET');
        $param = self::input(['fid' => 'int']);
        if (empty($param['fid'])) {
            return $this->json(self::output()->withCode(21002));
        }
        $res = self::purviewCheck('plugin/api/' . __FUNCTION__, $param['fid'], 8);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $res = Forms::dataCount($param);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $data = $res->getData();
        unset($data['form']);
        $res = self::output()->withCode(200)->withData($data);
        return $this->json($res);
    }

    /**
     * 表单添加修改页
     * @return array|\cs090\core\数据|string
     */
    public function dataView()
    {
        $this->requestCheck('GET');
        $fid = self::inputInt('fid');
        if (empty($fid)) {
            return $this->json(self::output()->withCode(21002));
        }
        $res = self::purviewCheck('plugin/api/' . __FUNCTION__, $fid, 2);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $id = self::inputInt('id');
        if (empty($id)) {
            return $this->json(self::output()->withCode(21002));
        }
        $fields = self::t('forms_fields')
            ->withWhere(['formid' => $fid, 'available' => 1, 'infront' => 1])
            ->onefieldList('identifier');
        $res = Forms::dataView($fid, $id, implode(',', $fields));
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $data = $res->getData();
        unset($data['form'], $data['fields']);
        $res = self::output()->withCode(200)->withData($data);
        return $this->json($res);
    }

    /**
     * 表单添加修改页
     * @return array|\Psr\Http\Message\ResponseInterface
     * @throws \SlimCMS\Error\TextException
     */
    public function dataForm()
    {
        $this->requestCheck('GET');
        $fid = self::inputInt('fid');
        if (empty($fid)) {
            return $this->json(self::output()->withCode(21002));
        }
        $res = self::purviewCheck('plugin/api/' . __FUNCTION__, $fid, 6);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $id = self::inputInt('id');
        $res = Forms::dataFormHtml($fid, $id, ['infront' => true]);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $data = $res->getData();
        $val = [];
        foreach ($data['fieldshtml'] as $v) {
            $val[] = ['id' => $v['id'], 'title' => $v['title'], 'identifier' => $v['identifier'], 'field' => $v['field']];
        }
        $data = ['fieldshtml' => $val];
        $res = self::output()->withCode(200)->withData($data);
        return $this->json($res);
    }

    /**
     * 数据添加修改保存
     * @return array|\Psr\Http\Message\ResponseInterface
     * @throws \SlimCMS\Error\TextException
     */
    public function dataSave()
    {
        $this->requestCheck('POST');
        $fid = self::inputInt('fid');
        if (empty($fid)) {
            return $this->json(self::output()->withCode(21002));
        }
        $res = self::purviewCheck('plugin/api/' . __FUNCTION__, $fid, 3);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $id = self::inputInt('id');
        $res = Forms::formView($fid);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $res = Forms::dataSave($fid, $id);
        return $this->json($res);
    }

    /**
     * 数据审核
     * @return array|\Psr\Http\Message\ResponseInterface
     * @throws \SlimCMS\Error\TextException
     */
    public function dataCheck()
    {
        $this->requestCheck('POST');
        $fid = self::inputInt('fid');
        if (empty($fid)) {
            return $this->json(self::output()->withCode(21002));
        }
        $res = self::purviewCheck('plugin/api/' . __FUNCTION__, $fid, 7);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $ids = self::input('ids');
        $ids = $ids ? explode(',', $ids) : [];
        $ischeck = self::inputInt('ischeck');
        $res = Forms::formView($fid);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $res = Forms::dataCheck($fid, $ids, $ischeck);
        return $this->json($res);
    }

    /**
     * 数据删除
     * @return array|\Psr\Http\Message\ResponseInterface
     * @throws \SlimCMS\Error\TextException
     */
    public function dataDel()
    {
        $this->requestCheck('POST');
        $fid = self::inputInt('fid');
        if (empty($fid)) {
            return $this->json(self::output()->withCode(21002));
        }
        $res = self::purviewCheck('plugin/api/' . __FUNCTION__, $fid, 4);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $ids = self::input('ids');
        $ids = $ids ? explode(',', $ids) : [];
        $res = Forms::formView($fid);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $res = Forms::dataDel($fid, $ids);
        return $this->json($res);
    }

    /**
     * 数据导出
     */
    public function dataExport()
    {
        $this->requestCheck('GET');
        $param = self::input(['fid' => 'int', 'page' => 'int', 'pagesize' => 'int']);
        if (empty($param['fid'])) {
            return $this->json(self::output()->withCode(21002));
        }
        $res = self::purviewCheck('plugin/api/' . __FUNCTION__, $param['fid'], 5);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $res = Forms::formView((int)$param['fid']);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }

        $res = Forms::dataExport($param);
        $data = $res->getData();
        $response = self::$response->getResponse();
        if (self::input('down') == 1) {
            if (!is_file($data['file'])) {
                $output = self::$output->withCode(21050);
                return $this->directTo($output);
            }
            $file = fopen($data['file'], 'r');
            $filesize = filesize($data['file']);
            ob_end_clean();
            $response = $response
                ->withHeader('Content-type', 'application/octet-stream')
                ->withHeader('Accept-Ranges', 'bytes')
                ->withHeader('Accept-Length', $filesize)
                ->withHeader('Content-Disposition', 'attachment; filename=' . basename($data['file']));
            $content = fread($file, $filesize);
            fclose($file);
        } else {
            $response = $response->withHeader('Content-type', 'text/html');
            $content = $data['text'] . '<script>location="' . $res->getReferer() . '";</script>';
        }
        $response->getBody()->write($content);
        return $response;
    }

    /**
     * 上传图片
     * DEMO:curlPost('plugin/api/uploadFile', ['file'=>new \CURLFile(realpath('E:/www/test/1.jpg'))]);
     */
    public function uploadFile()
    {
        $this->requestCheck('POST');
        $res = self::purviewCheck('plugin/api/' . __FUNCTION__);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $type = self::inputString('type');
        $type = in_array($type, ['img', 'addon', 'media']) ? $type : 'img';
        $file = self::input('file', $type);
        $res = self::$output->withCode(200)->withData(['file' => $file]);
        return $this->json($res);
    }

    /**
     * 获取OPENID
     * @return array|\Psr\Http\Message\ResponseInterface
     */
    public function getOpenid()
    {
        $this->requestCheck('GET');
        $res = self::purviewCheck('plugin/api/' . __FUNCTION__);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $code = self::inputString('code');
        $res = WxModel::getOpenid($code);
        return $this->json($res);
    }

    /**
     * 解密用户信息
     * @return array|\Psr\Http\Message\ResponseInterface
     */
    public function decryptData()
    {
        $this->requestCheck('GET');
        $res = self::purviewCheck('plugin/api/' . __FUNCTION__);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $data = self::input(['sessionkey' => 'string', 'encrypteddata' => 'string', 'iv' => 'string']);
        $res = WxModel::decryptData($data);
        return $this->json($res);
    }

    /**
     * 生成小程序二维码
     */
    public function qrcode()
    {
        $this->requestCheck('GET');
        $res = self::purviewCheck('plugin/api/' . __FUNCTION__);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $scene = self::input('scene');
        $width = self::input('width', 'int') ?: 430;
        $page = self::input('page');
        $param = ['scene' => $scene, 'width' => $width];
        $page && $param['page'] = $page;
        WxModel::qrcode($param);
        $str = header('Content-type: image/jpeg');
        exit($str);
    }

    /**
     * 发送小程序订阅消息
     * @return array|\Psr\Http\Message\ResponseInterface
     * @throws \DI\DependencyException
     * @throws \DI\NotFoundException
     */
    public function sendTemplateMessage()
    {
        $this->requestCheck('GET');
        $res = self::purviewCheck('plugin/api/' . __FUNCTION__);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $touser = self::inputString('touser');
        $template_id = self::inputString('template_id');
        $data = self::inputString('data');
        if ($data) {
            $data = json_decode($data, true);
        }
        $page = self::inputString('page');
        $res = WxModel::sendTemplateMessage($touser, $template_id, $data, $page);
        return $this->json($res);
    }

    /**
     * 获取公众号CODE
     */
    public function getCode()
    {
        $this->requestCheck('GET');
        $scope = self::inputString('scope');
        $redirect = self::inputString('redirect');
        $res = WxModel::getCode($scope, $redirect);
        header('location:' . $res->getReferer());
        exit;
    }

    /**
     * 获取微信用户信息
     * @return array|\Psr\Http\Message\ResponseInterface
     */
    public function getUserInfo()
    {
        $this->requestCheck('GET');
        $res = self::purviewCheck('plugin/api/' . __FUNCTION__);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $code = self::inputString('code');
        $res = WxModel::getUserInfo($code);
        return $this->json($res);
    }

    /**
     * 生成微信分享签名
     * @return array|\Psr\Http\Message\ResponseInterface
     */
    public function wxJsapiConfig()
    {
        $this->requestCheck('GET');
        $res = self::purviewCheck('plugin/api/' . __FUNCTION__);
        if ($res->getCode() != 200) {
            return $this->json($res);
        }
        $url = self::inputString('url');
        $res = WxModel::wxJsapiConfig($url);
        return $this->json($res);
    }
}
