<?php
/**
 * 后台首页控制类
 * @author zhucy
 */

declare(strict_types=1);

namespace App\Control\admincp\plugin;

use App\Control\admincp\AdmincpControl;
use App\Core\Forms;
use App\Model\plugin\PluginModel;
use SlimCMS\Core\Request;
use SlimCMS\Core\Response;
use SlimCMS\Error\TextException;

class ApiControl extends AdmincpControl
{
    private static $identifier = 'api';

    public function __construct(Request $request, Response $response)
    {
        parent::__construct($request, $response);
        $res = PluginModel::getConfig(self::$identifier);
        if ($res->getCode() != 200) {
            throw new TextException($res->getCode());
        }
        self::$config['plugin'] = $res->getData()['config'];
    }

    /**
     * 插件参数设置
     * @return array|\Psr\Http\Message\ResponseInterface
     */
    public function setConfig()
    {
        $formhash = self::input('formhash');
        if ($formhash) {
            $res = Forms::submitCheck($formhash);
            if ($res->getCode() != 200) {
                return $this->directTo($res);
            }
            $data = self::input([
                'tokenCheck' => 'int',//是否开启token校验
                'appid' => 'string',//微信APPID
                'appsecret' => 'string',//微信APPSECRET
                'refererWhite' => 'string',//来路白名单
                'tokenTTL' => 'int'//TOKEN有效时长
            ]);
            $res = PluginModel::setConfig(self::$identifier, $data);
            return $this->directTo($res);
        }
        self::$output = self::$output->withData(['config'=>self::$config['plugin']]);
        return $this->view(self::$output);
    }
}
