<?php

/**
 * @author zhucy
 */

declare(strict_types=1);

namespace App\Model\plugin\api;

use SlimCMS\Abstracts\ModelAbstract;
use SlimCMS\Interfaces\OutputInterface;

class ApiModel extends ModelAbstract
{
    /**
     * 插件外部调用的勾子
     * @return array
     */
    public static function hook(): array
    {
        return [
            'App\Table\FormsTable\dataSaveAfter' => function ($param) {
                return ApimanageModel::formApiManage((int)$param[0]['id']);
            }
        ];
    }

    /**
     * 注入插件提示信息的输出类
     * @return OutputInterface
     */
    public static function output(): OutputInterface
    {
        return self::$output->withPrompt(self::prompt());
    }

    /**
     * 插件提示信息(防止与原提示代码重复，以9000000开始)
     * @return array
     */
    private static function prompt(): array
    {
        return [
            9000000 => '无此接口调用权限',
            9000001 => '此接口权限尚未开启',
            9000002 => 'accessToken解密失败',
            9000003 => 'accessToken已过期',
            9000004 => 'accessToken校验未开启',
            9000005 => '此accessToken已失效',
            9000006 => '请先在API参数设置中设置微信appid和appsecret',
            9000007 => '此应用ID不存在',
        ];
    }
}
