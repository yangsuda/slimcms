<?php

/**
 * 应用模型类
 * @author zhucy
 */

declare(strict_types=1);

namespace App\Model\plugin\api;

use SlimCMS\Core\Wxxcx;
use App\Model\plugin\PluginModel;
use SlimCMS\Core\Wxgzh;
use SlimCMS\Error\TextException;
use SlimCMS\Helper\Ipdata;
use SlimCMS\Interfaces\OutputInterface;

class WxModel extends ApiModel
{
    private static function getConfig(): array
    {
        $res = PluginModel::getConfig('api');
        if ($res->getCode() != 200) {
            throw new TextException($res->getCode());
        }
        return $res->getData()['config'];
    }

    /**
     * 获取微信用户信息
     * @param string $code
     * @return OutputInterface
     * @throws TextException
     */
    public static function getUserInfo(string $code): OutputInterface
    {
        if (empty($code)) {
            return self::output()->withCode(21002);
        }
        $config = self::getConfig();
        if (empty($config['appid']) || empty($config['appsecret'])) {
            return self::output()->withCode(9000006);
        }
        $data = [];
        $data['code'] = $code;
        $data['appid'] = $config['appid'];
        $data['appsecret'] = $config['appsecret'];
        $output = self::output()->withData($data);
        return Wxgzh::getUserInfo($output);
    }

    /**
     * 生成微信分享签名
     * @param string $url
     * @return OutputInterface
     * @throws TextException
     */
    public static function wxJsapiConfig(string $url): OutputInterface
    {
        if (empty($url)) {
            return self::output()->withCode(21002);
        }
        $config = self::getConfig();
        if (empty($config['appid']) || empty($config['appsecret'])) {
            return self::output()->withCode(9000006);
        }
        $data = [];
        $data['url'] = $url;
        $data['appid'] = $config['appid'];
        $data['appsecret'] = $config['appsecret'];
        $output = self::output()->withData($data);
        return Wxgzh::wxJsapiConfig($output);
    }

    /**
     * 获取公众号CODE
     * @param string $scope base、userinfo，默认userinfo
     * @param string $redirect
     * @return OutputInterface
     * @throws TextException
     */
    public static function getCode(string $scope = 'userinfo', string $redirect = ''): OutputInterface
    {
        if (empty($url)) {
            return self::output()->withCode(21002);
        }
        $config = self::getConfig();
        if (empty($config['appid']) || empty($config['appsecret'])) {
            return self::output()->withCode(9000006);
        }
        $data = [];
        $data['appid'] = $config['appid'];
        $data['appsecret'] = $config['appsecret'];
        $data['scope'] = $scope;
        $data['redirect'] = $redirect;
        $output = self::output()->withData($data);
        return Wxgzh::getCode($output);
    }

    /**
     * 发送小程序订阅消息
     * @param string $touser 消息接收者
     * @param string $template_id 模板ID
     * @param array $data 模板数据
     * @param array $page 小程序URL
     * @return OutputInterface
     * @throws TextException
     * @throws \DI\DependencyException
     * @throws \DI\NotFoundException
     */
    public static function sendTemplateMessage(string $touser, string $template_id, array $data, string $page = ''): OutputInterface
    {
        if (empty($touser) || empty($template_id) || empty($data)) {
            return self::output()->withCode(21002);
        }
        $config = self::getConfig();
        if (empty($config['appid']) || empty($config['appsecret'])) {
            return self::output()->withCode(9000006);
        }
        $data = [];
        $data['appid'] = $config['appid'];
        $data['appsecret'] = $config['appsecret'];
        $data['touser'] = $touser;
        $data['template_id'] = $template_id;
        $data['data'] = $data;
        $data['page'] = $page;
        $output = self::output()->withData($data);
        return Wxxcx::sendTemplateMessage($output);
    }

    /**
     * 生成小程序二维码
     * @param array $param
     * @return OutputInterface
     * @throws TextException
     */
    public static function qrcode(array $param): OutputInterface
    {
        if (empty($url)) {
            return self::output()->withCode(21002);
        }
        $config = self::getConfig();
        if (empty($config['appid']) || empty($config['appsecret'])) {
            return self::output()->withCode(9000006);
        }
        $param['appid'] = $config['appid'];
        $param['appsecret'] = $config['appsecret'];
        $output = self::output()->withData($param);
        return Wxxcx::getwxacodeunlimit($output);
    }

    /**
     * 解密用户信息
     * @param array $param
     * @return OutputInterface
     */
    public static function decryptData(array $param): OutputInterface
    {
        if (empty($url)) {
            return self::output()->withCode(21002);
        }
        $output = self::output()->withData($param);
        $res = Wxxcx::decryptData($output);
        //用户保存
        self::userSave($res->getData());
        return $res;
    }

    /**
     * 用户保存
     * @param $param
     * @return OutputInterface
     * @throws TextException
     */
    private static function userSave($param)
    {
        if (empty($param['openid'])) {
            return self::output()->withCode(21003);
        }
        $row = self::t('api_wxusers')->withWhere(['openid' => $param['openid']])->fetch();
        $data = [];
        !empty($param['nickName']) && $data['nickname'] = $param['nickName'];
        !empty($param['avatarUrl']) && $data['headimgurl'] = $param['avatarUrl'];
        if (!empty($row)) {
            $data && self::t('api_wxusers')->withWhere($row['id'])->update($data);
        } else {
            $data['openid'] = $param['openid'];
            $data['createtime'] = TIMESTAMP;
            $data['ip'] = Ipdata::getip();
            self::t('api_wxusers')->insert($data);
        }
        return self::output()->withCode(200);
    }

    /**
     * 获取OPENID
     * @param string $code
     * @return OutputInterface
     * @throws TextException
     */
    public static function getOpenid(string $code): OutputInterface
    {
        if (empty($code)) {
            return self::output()->withCode(21002);
        }
        $config = self::getConfig();
        if (empty($config['appid']) || empty($config['appsecret'])) {
            return self::output()->withCode(9000006);
        }
        $data = [];
        $data['code'] = $code;
        $data['appid'] = $config['appid'];
        $data['appsecret'] = $config['appsecret'];
        $output = self::output()->withData($data);
        $res = Wxxcx::getOpenid($output);
        //用户保存
        self::userSave($res->getData());
        return $res;
    }
}
