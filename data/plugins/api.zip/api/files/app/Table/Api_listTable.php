<?php

declare(strict_types=1);

namespace App\Table;

use App\Core\Table;
use App\Model\plugin\api\ApimanageModel;

class Api_listTable extends Table
{
    /**
     * 数据保存前的自定义处理
     * @param $data
     * @param array $row
     * @return int
     */
    public function dataSaveBefore(&$data, $row = [], $options = []): int
    {
        if (defined('MANAGE') && MANAGE == 1) {
            !empty($data['result']) && $data['result'] = self::$request->htmlspecialchars($data['result'], 'de');
            $data['identifier'] = ApimanageModel::getIdentifier($data['path'], aval($data, 'formid'), aval($data, 'openapiid'))->getData()['identifier'];
        }
        return 200;
    }

    /**
     * 列表数据获取之后的自定义处理
     * @param $data
     * @param $param
     * @return int
     * @throws \SlimCMS\Error\TextException
     */
    public function dataListAfter(&$data, $param): int
    {
        if (defined('MANAGE') && MANAGE == 1) {
            $data['requestFormid'] = self::t('forms')->withWhere(['table' => 'api_request'])->fetch('id');
            $data['responseFormid'] = self::t('forms')->withWhere(['table' => 'api_response'])->fetch('id');
        }
        return 200;
    }
}
